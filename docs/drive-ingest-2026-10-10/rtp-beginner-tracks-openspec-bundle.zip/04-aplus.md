---

# SPEC-04 — Capability: CompTIA A+ Track (track-aplus)

## 04.1 Alignment and frame

Official alignment: A+ V15, Core 1 (220-1201) and Core 2 (220-1202), CompTIA exam-objectives documents version 3.0 (fetched October 10, 2026). A+ requires BOTH cores; a Core-1-only demo is not "the A+ certification" and the UI never implies otherwise. The track is labeled beginner preview with visible objective coverage (REQ-MAN-07). All scored items are original; AI may draft under the owner-directed constraints (SPEC-00 section 00.3); every scored item passes the RedEye AI review lane with a written per-item log before release (SPEC-08A). Non-endorsement: REQ-BRAND-01/02 apply on every surface.

## 04.2 Shared foundations lesson

One shared lesson, "How to diagnose without guessing," opens both cores: a repeatable loop of identify symptoms, form a hypothesis, pick a safe test, isolate the cause, verify the fix, document the result. Every later lesson and both scenario tasks cite this loop. At least half of all scored A+ items ask for a next action or diagnosis rather than a definition (the preliminary spec's bar, adopted as REQ-AP-06).

## 04.3 Core 1 modules (COMPTIA-A-1201)

| # | Module | Official domain | Weight |
|---|---|---|---|
| A1 | Mobile devices and accessories: laptop parts, docks, wireless connections, synchronization | Domain 1 | 13% |
| A2 | Networking basics: IP address, gateway, DNS, DHCP, ports, Wi-Fi, SOHO setup | Domain 2 | 23% |
| A3 | Hardware and peripherals: CPU/RAM/storage, power, connectors, printers | Domain 3 | 25% |
| A4 | Virtualization and cloud: host vs guest, VM resource allocation, cloud service models | Domain 4 | 11% |
| A5 | Hardware/network troubleshooting: symptoms, safe tests, isolate, verify, document | Domain 5 | 28% |

Each module ships one 5-10 minute lesson, one short practice set, and one task or worked example.

## 04.4 Core 2 modules (COMPTIA-A-1202)

| # | Module | Official domain | Weight |
|---|---|---|---|
| B1 | Operating systems: installation, files, accounts, Windows tools, intro Linux/macOS | Domain 1 | 28% |
| B2 | Security: authentication, permissions, phishing, malware response, safe disposal | Domain 2 | 28% |
| B3 | Software troubleshooting: OS/app failures, malware symptoms, mobile software faults | Domain 3 | 23% |
| B4 | Operational procedures: tickets, backups, change control, safety, privacy, communication | Domain 4 | 21% |

## 04.5 Requirements

**REQ-AP-01 (SHALL).** Starter bank: 120 reviewed original items, 60 per core. Core 1 domain allocation 8/14/15/7/16 across A1-A5; Core 2 allocation 17/17/14/12 across B1-B4. These are study allocations approximating official weights, stored in exam.json as study allocation, never presented as an official test model.
Scenario: Given the released packs, when the manifest validator runs, then per-domain released counts equal the allocations and every item carries a complete provenance record.

**REQ-AP-02 (SHALL).** October 23 cut: 24 reviewed items — 16 Core 1 networking/troubleshooting items (A2/A5) and 8 Core 2 ticketing/security items (B2/B4) — plus one complete lesson in each core (A2 networking basics; B4 operational procedures). Other modules display as planned outlines.
Scenario: Given the demo build, when the track opens, then exactly the cut scope is released, the rest is labeled planned, and practice sets draw only from the 24 reviewed items.

**REQ-AP-03 (SHALL).** Practice sets are separate from any later holdout assessment; no screen, export or tutor string claims pass prediction from this bank.
Scenario: Given a UI fixture sweep, when all score screens render, then none contains a pass-probability or exam-readiness claim (snapshot-tested strings).

**REQ-AP-04 (SHALL).** Virtualization is illustrated by the existing PE VM-creation simulator, labeled in-line: "Nutanix example of a general concept." It is never presented as an A+ operating-system or hardware lab.
Scenario: Given lesson A4, when the simulator link renders, then the label string is present.

**REQ-AP-05 (SHALL).** Hardware, printer and OS-tools objectives without simulation support ship as worked examples, clearly labeled, never as fake interactive completions (Plan v2 L-08 honesty rule).
Scenario: Given modules A3/B1, when rendered, then unsupported interactive claims are absent and worked examples carry the label.

**REQ-AP-06 (SHALL).** At least half of scored items are next-action/diagnosis items. CI counts item stems tagged `type: diagnosis` vs `type: recall` in front matter and fails below 50% diagnosis.
Scenario: Given the Core 1 pack with 30 diagnosis and 30 recall items, when CI runs, then it passes; given 29 diagnosis items, it fails naming the deficit.

**REQ-AP-07 (SHALL).** Simulator tie-in: the DNS help-desk ticket scenario (SPEC-07, scenario aplus-dns-01). The demo tutor prompt — "The website works by IP address but not by name. Give me one hint, not the answer." — is in the rehearsed tutor set and must resolve to the reviewed DNS lesson (SPEC-08).

## 04.6 Content files

content/exams/COMPTIA-A-1201/lessons/{a1..a5}.md, questions/core1-part1.md (60 items); content/exams/COMPTIA-A-1202/lessons/{b1..b4}.md, questions/core2-part1.md (60 items); provenance JSON per item under content/provenance/. Question markdown uses the parser format from SPEC-00; multi-select items use "**Correct Answer: B, D**" form only (the "B and D" form is repaired globally in SPEC-09 R-07 and forbidden in new content by lint).

## 04.7 Lesson synopses (authoring targets)

Each synopsis is the contract the author writes to: the teaching points a reviewer checks, and the practice-set hook. Lessons are 5-10 minutes of reading, original prose, no vendor text lifted.

**A1 Mobile devices and accessories.** Teaching points: what makes a laptop field-serviceable (RAM, storage, battery, keyboard, Wi-Fi card); dock vs port replicator; USB-C/Thunderbolt display and power negotiation at a concept level; pairing and sync (what actually syncs: contacts, photos, app data). Practice hook: "A docked laptop charges but shows no external display — what do you check first?" Worked example: reading a laptop spec sheet and identifying upgrade paths.

**A2 Networking basics (October 23 lesson).** Teaching points: the four things every host needs (IP, mask, gateway, DNS); what DHCP hands out and what breaks when it does not; what DNS translates and the classic "works by IP, not by name" symptom; ports as service doors (80/443/53 as examples); SOHO Wi-Fi basics (SSID, passphrase, 2.4 vs 5 GHz). Practice hook: read a workstation config panel and name the wrong field. This lesson is the citation target for the demo tutor prompt and the aplus-dns-01 scenario.

**A3 Hardware and peripherals.** Teaching points: CPU/RAM/storage roles and how to tell which one is the bottleneck by symptom; PSU wattage and connector basics; display and USB connector families; printer concepts (local vs network, drivers, spooler). Practice hook: match the symptom to the subsystem. Worked example: a build-parts compatibility check.

**A4 Virtualization and cloud.** Teaching points: host vs guest; hypervisor in one paragraph; why resource allocation matters (vCPU, RAM, disk); cloud service models (IaaS/PaaS/SaaS) with everyday analogies. The PE VM-creation simulator illustrates, labeled per REQ-AP-04.

**A5 Hardware/network troubleshooting.** Teaching points: the shared diagnosis loop applied to concrete cases; safe tests before invasive ones; isolate-by-halves; verify with the user's own workflow; document so the next tech does not start over. Practice hook: order-free "what is your next step" items (ordering items stay quarantined per R-03).

**B1 Operating systems.** Teaching points: what an OS install actually stages; files, paths and permissions at a beginner level; user accounts and why least privilege exists; the Windows toolbox (Task Manager, Settings vs Control Panel, File Explorer); Linux/macOS concepts mapped to the same ideas.

**B2 Security (October 23 partial lesson scope with B4).** Teaching points: authentication factors; permissions vs authentication; phishing anatomy (urgency, sender mismatch, link inspection); malware first response (isolate, report, no heroics); safe disposal (why deleting is not erasing). Practice hook: sort the real warning signs from the noise in a synthetic message.

**B3 Software troubleshooting.** Teaching points: OS won't boot vs app won't start vs everything is slow; malware symptoms that masquerade as hardware faults; mobile app fault basics (cache, permissions, OS version).

**B4 Operational procedures (October 23 lesson).** Teaching points: what a ticket is for (communication and history, not bureaucracy); backup basics (3-2-1 at concept level); change control as "write down what you will do before you do it"; safety and privacy as habits; how to talk to a frustrated user. This lesson powers the ticketing half of the demo cut and the resolution-note step of aplus-dns-01.

## 04.8 October 23 cut outline (24 items)

Core 1 (16 items, A2/A5): DNS purpose and symptom recognition (4); DHCP lease behavior (2); gateway role (2); port recognition (2); safe-test selection from a symptom (4); isolate-and-verify sequencing as single-choice next-step items (2). Core 2 (8 items, B2/B4): phishing signal recognition (3); ticket field purpose and resolution-note quality (3); change-control and backup basics (2). Every cut item names its lesson, objective ID, reviewer and provenance record; the practice set draws only from these 24 and says so on screen.
