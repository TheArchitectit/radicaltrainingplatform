---

# SPEC-11 — Tasks and Sprint Plan

## 11.1 Rules

Dependency-ordered tasks; each names files, commands and its requirement IDs. Branches: feature/rtp-beginner-tracks (tracks, UI, scenarios, repairs), feature/rtp-tutor-demo (gateway and panel), content/nca75-current-blueprint (remap, lessons, pilot). No PRs; merge direct to main only with the full gate chain green (owner standing rule). Dates are planning checkpoints, not measured estimates; October 23 is a Friday; 13 calendar days remain from October 10 and builder/reviewer capacity is unknown — the plan degrades by cutting released scope visibly, never by shipping unreviewed material.

## 11.2 Sprint A — October 10-12: contracts, repairs that block everything, first content

| ID | Task | Requirements | Key files / commands |
|---|---|---|---|
| T-01 | Repair PWA boot import; add check-imports.py with failing+passing fixtures | R-01, CI-03 | Web/js/views/pe-reports.js; scripts/check-imports.py |
| T-02 | Repair vuln gate + fixture suite | CI-01 | .github/scripts/vuln_gate.py; tests/gates/test_vuln_gate.py |
| T-03 | Extend AnswerRegex + parse/catalog reconciliation; repair NCP-AI-Part4 keys | R-07 | Core/Services/QuestionParser.cs; NCP-AI-Part4.md; Core.Tests/QuestionParserTests.cs |
| T-04 | Ordered-response type + quarantine/convert ordering items | R-03 | Core/Models/Question.cs; ExamSessionViewModel; Core.Tests |
| T-05 | Retry accounting fix | R-04 | ExamSessionViewModel; Core.Tests |
| T-06 | Manifest system: models, loader, catalog, blueprint override, validator | REQ-MAN-01..07 | SPEC-02 file list; python3 scripts/validate-manifests.py |
| T-07 | Four exam.json + three track.json with sources and review dates | REQ-MAN-06 | content/exams/*, content/tracks/* |
| T-08 | First reviewed lesson + question fixtures (A+ A2; Network+ N5) | REQ-AP-02, REQ-NP-02 | content/exams/COMPTIA-A-1201/lessons/a2.md etc. |
| T-09 | Begin NCA remap inventory (140 rows) | REQ-NCA-01 | content/exams/NCA-75/remap.csv |
| T-10 | Answer-position distribution report | R-09 | scripts/report-key-distribution.py |

## 11.3 Sprint B — October 13-16: one learning loop, end to end

| ID | Task | Requirements |
|---|---|---|
| T-11 | Track picker, lesson reader, practice view | REQ-UI-01..03, REQ-BRAND-01/02 |
| T-12 | ProgressStore + wiring + E2E save/reload/failure tests | REQ-UI-04/05, R-06 |
| T-13 | ticket-lab.js renderer; aplus-dns-01 + netplus-gw-01 with validators and negative fixtures | REQ-SC-01..06, SPEC-07 07.3/07.4 |
| T-14 | Scenario validator sweep repairs (all 44; us-bucket-01) | R-02, REQ-DEMO-06 |
| T-15 | Bridge handlers: real effects or removal; desktop SessionStore consumption | R-05, R-06 |
| T-16 | Catalog tests, multi-select scoring tests, save/reload/error tests | REQ-MAN-05, L-06 |
| T-17 | Lint extension + manifest validator in CI | SPEC-10 10.6 |
| T-18 | Coverage threshold enforcement | CI-02 |

## 11.4 Sprint C — October 17-19: finish the demo packs

| ID | Task | Requirements |
|---|---|---|
| T-19 | A+ cut complete: 24 reviewed items, 2 complete lessons | REQ-AP-02 |
| T-20 | Network+ cut complete: 25 reviewed items, 2 complete lessons | REQ-NP-02 |
| T-21 | Demo mode: seed, one-click reset, mode label, ephemeral store | REQ-DEMO-01..06, REQ-UI-07/08 |
| T-22 | Pages predeploy gate (imports, smoke, bundle check) | CI-03 |
| T-23 | Tutor slice behind its gates, or recorded-example fallback | REQ-AI-01..07 |
| T-24 | Option shuffling with stable IDs | R-09 |
| T-25 | Packaging repairs PKG-01..04 + clean-install tests | SPEC-10 10.5 |

## 11.5 Sprint D — October 20-22: freeze and rehearse

| ID | Task | Requirements |
|---|---|---|
| T-26 | Installed-host, offline, keyboard/projector, reset-between-groups rehearsal on the actual demo host | REQ-UI-06, REQ-DEMO-05, TM-40/45/50 |
| T-27 | Tutor evaluation report and go/no-go; fallback labeling check | REQ-AI-06/07 |
| T-28 | Screenshots/video backup; non-AI backup path | REQ-AI-07 |
| T-29 | Freeze: record branch, base/head SHA, changed files, gate results, RedEye lane logs and seeded-defect self-test record, usable build | SPEC-11 11.7 |
| T-30 | Demo script final: 90-second loop (learn, try, ask, verify) + exact disclaimer + "no patient or business system is involved" line | REQ-BRAND-02 |

Explicitly not in Sprint D: no architecture migration, no new content authoring after freeze.

### Sprint A/B additions for the final-audit register (owner: address everything)

| ID | Task | Requirements |
|---|---|---|
| T-37 | Semantic item identity for legacy banks + collision detector; retry outcome-set policy | R-13, R-14 |
| T-38 | Study-continuation restore; streak/Skip repairs | R-15, R-17 |
| T-39 | Disposal guards on cached simulator references | R-16 |
| T-40 | PDF export: canonical ID vs display label; vendor-neutral footer; atomic session save + corrupt recovery | R-18, R-20 |
| T-41 | Installed-bundle content independence; Legacy bridge surface narrowing; release-link truth | R-19 |
| T-42 | CefGlue NoSandbox scoped hardening review + navigation allowlist decision | R-21 |
| T-43 | Web runtime batch: this.root lifecycle, ci-networking accessor, CLI async, audit-log ordering, router serialization, per-item validator isolation, scenario attempt/history, cosmetics | R-22 |
| T-44 | Storage recovery boundary tests (corrupt entry, quota, blocked) | R-23 |
| T-45 | ShellCheck gate + packaging behavior fixtures | R-24 |
| T-46 | RedEye lane: checks, logs, ship-gate, seeded-defect self-test | REQ-REV-01..06 |

T-37..T-46 distribute across Sprints A-C by dependency: T-46 in Sprint A; T-37/T-40 in Sprint A-B (content depends on identity and export truth); T-43 starts immediately after T-01 (same surface); T-41/T-45 with the packaging work in Sprint C; T-42's review concludes before the desktop demo path is chosen; T-44 with T-12.

## 11.6 Sprint E — after EPIC, before California: the NCA cut

| ID | Task | Requirements |
|---|---|---|
| T-31 | Complete remap.csv (started T-09) with RedEye lane logs and seeded-defect self-test record | REQ-NCA-01 |
| T-32 | NCA-75 exam.json current blueprint; InitNca75 retired; blueprint fixtures | REQ-NCA-05 |
| T-33 | 14 lessons + 40-item pilot (remapped + newly authored gap fills) | REQ-NCA-02/06 |
| T-34 | Cheatsheet correction + beta logistics cleanup + scheduling-link currency | REQ-NCA-04, C-07 |
| T-35 | Four NCA scenarios with validators and walkthroughs | REQ-NCA-07, REQ-SC-01..06 |
| T-36 | Travel freeze per REQ-NCA-08 once the itinerary confirms the cutoff (ASM-09) | REQ-NCA-08 |

NCA review starts in parallel during Sprints B-D precisely so the post-EPIC window is not the only path. If measured capacity falls short, report the forecast and proposed options to Roger. Only an owner-approved scope change reduces the selected release target; never silently drop content or publish unreviewed items.

## 11.7 Release evidence (every release)

Each implementation report names: branch, base/head SHA, changed files, tests run with counts (e.g., gates N/N at SHA), RedEye lane logs and seeded-defect self-test record, the usable build, and what was NOT independently verified. Suggested branches are proposals until created. No merge, PR, public deployment or purchase follows from this package.

## 11.8 Review workflow: the RedEye lane (owner-directed)

Every scored item passes the RedEye AI review lane (SPEC-08A) before release: author drafts (original work; provenance record generated at draft time) -> RedEye per-item checks (key vs source material, objective mapping, position bias, originality screen) -> written per-item log with pass/return verdict -> items with passing current logs enter the released pack at the next compile. Roger may spot-check at his discretion; he is not the reviewer of record and carries no mandatory review load. Remapped legacy items pass the same lane with its remap-aware checks (key re-verification, explanation re-read, mapping check, rights status). The lane's logs and the seeded-defect self-test record are part of the release evidence (SPEC-11 11.7). Fail-closed: no lane, no release (REQ-REV-05).

## 11.9 Capacity math the plan is honest about

The demo window needs: 49 reviewed CompTIA items (24+25), 4 complete lessons, 2 scenarios, 4 views, the repair set, the gates, and rehearsal. The California window adds: 140 remap decisions, 40 pilot items, 14 lessons, 4 scenarios. The owner's RedEye directive removes the human-review bottleneck: review throughput is now a lane-compute question, not a calendar question, and Roger carries no mandatory review load. Authoring throughput and engineering execution are the remaining constraints; the plan front-loads reviewable batches (T-08 on October 12, cut packs by October 19) and keeps the cut lines as visible scope reductions rather than quality reductions. The RedEye lane itself (T-46) lands in Sprint A because every content task after it depends on the ship-gate existing.

## 11.10 Sprint governance

Each sprint closes with a mini-retrospective written into the implementation report: what the sprint planned, what landed, what slipped and why, which register rows moved to evidenced, and the gate pass count at the sprint's head SHA. Slippage handling preserves owner control: a slipping content task produces a forecast and proposed reduced count for Roger to approve before the selected scope changes; a slipping repair task on the demo critical path (R-01, R-02, R-03, R-04, R-07) triggers the RSK-02 fallback rehearsal with the recorded build; a slipping gate task blocks merge of everything behind it, because the chain is the release condition. Mid-sprint scope additions go through the same register: new work gets an ID, an owner role and acceptance criteria before a line is written — the register is the single place where "address everything" stays true, because everything means every row, not every idea that appears mid-flight.
