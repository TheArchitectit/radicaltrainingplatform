---

# SPEC-03 — Capability: Beginner Study UI and Demo Mode

## 03.1 Purpose

Add the missing learning loop to the Web PWA — pick a track, read a lesson, practice with deterministic scoring, see progress, reset — plus the owner-directed demo mode across all simulator content. This is the surface the October 23 room actually touches.

## 03.2 Requirements

**REQ-UI-01 (SHALL).** A track-picker view (Web/js/views/track-picker.js, route /tracks) lists the three tracks with display names, coverage percentage, preview label and the exact non-endorsement disclaimer string from REQ-BRAND-02. It is the PWA start route in demo mode.
Scenario: Given a fresh profile, when the app opens /tracks, then three cards render, the NCA card shows "Nutanix Certified Associate 7.5" (not a beta label), and the disclaimer text matches REQ-BRAND-02 byte-for-byte.

**REQ-UI-02 (SHALL).** A lesson-reader view (lesson-reader.js, route /tracks/<trackId>/lessons/<lessonId>) renders reviewed original lesson markdown with objective IDs from the manifest. Unreleased modules render as "planned" outlines, never as dead links.
Scenario: Given the A+ Core 1 networking lesson, when rendered, then its objective IDs (per exam.json) appear, and the four planned sibling modules show as planned.

**REQ-UI-03 (SHALL).** A practice view (practice.js) runs scored sets from the pack: single-select and multi-select items, immediate review mode with explanations, deterministic scoring in Core-identical rules (SPEC-09 R-03/R-04 repairs apply). Study mode offers hints; assessment-style runs hide hints and the tutor until submission (Plan v2 L-01).
Scenario: Given a 5-item multi-select fixture set, when the learner answers, then scores match the Core fixture vectors exactly, and the review screen shows the reviewed explanation per item.

**REQ-UI-04 (SHALL).** Progress persists locally through ProgressStore (Web/js/core/ProgressStore.js over StateStore's IndexedDB/localStorage). Reload, browser restart and PWA relaunch preserve attempts, flags and per-item results; storage failure (full/denied) surfaces an honest recoverable error, never a false save (Plan v2 L-02).
Scenario: Given answered items, when the PWA is killed and relaunched, then progress is intact. Given IndexedDB disabled and localStorage blocked, when a save is attempted, then the UI reports that progress cannot be saved.

**REQ-UI-05 (SHALL).** Progress durability is proven end-to-end, closing the audit finding that persistence handlers exist but nothing calls them. The practice view calls ProgressStore on every scored event; a Playwright/browser test answers items, reloads, and asserts restored state.
Scenario: Given the E2E fixture, when the test completes, then the restored counts equal the pre-reload counts.

**REQ-UI-06 (SHALL).** Study works fully offline after install: lessons, questions, scoring, progress, scenarios (Plan v2 L-10). Network-disabled E2E covers fresh-load-after-install, failed download and pack update. Uncached tutor shows an explicit unavailable state.
Scenario: Given the installed PWA with radio disabled, when the learner completes a lesson plus practice set plus the DNS scenario, then everything functions and the tutor button shows its offline state.

**REQ-UI-07 (SHALL).** One-click station reset clears the progress/ and scenario/ keyspaces and reseeds every scenario fixture, returning the station to the group-start state without clearing app code or packs (REQ-DEMO-03).
Scenario: Given a dirty station (answered items, completed scenarios), when reset is tapped and confirmed, then the track picker shows zero progress and each scenario's seed state verifies via its own validator's negative path.

**REQ-UI-08 (SHALL).** No identity collection. No name, email, account or student ID is requested anywhere in the track, practice, scenario or tutor flows.
Scenario: Given a full walkthrough, when every screen is inspected, then no identity field exists.

**REQ-BRAND-01 (SHALL).** Naming is nominative only: "helps you prepare for the CompTIA A+ exam" phrasing is permitted; "approved", "official", "certified by", CompTIA/Nutanix logos or marks in branding are forbidden anywhere in UI, manifests, lesson text and demo script.
Scenario: Given a repository grep fixture list of forbidden strings and mark assets, when CI runs the brand check, then any hit fails the build.

**REQ-BRAND-02 (SHALL).** The exact disclaimer — "This is independent study material. It is not official training and is not endorsed or approved by CompTIA, Nutanix, or any other certification body." — appears on the track picker, each exam's overview screen, and in the demo script. The string is stored once (manifest field) and rendered by reference.
Scenario: Given the UI fixture, when the three surfaces render, then each contains the exact string; a snapshot test pins it.

**REQ-DEMO-01..06 (SHALL).** Demo mode per SPEC-01 section 01.4b: all 44 existing scenarios plus the six new scenarios boot, run and report completion correctly from seeded state; one-click reset; no account, persistence or network required; projector-readable and keyboard-operable.
Scenario: Given the scripted demo-mode sweep (TM-45), when it runs against the release build, then all 50 scenarios pass boot/run/incomplete-then-complete checks, and the sweep report names each scenario ID and result.

## 03.3 Exact files

New: Web/js/views/track-picker.js, lesson-reader.js, practice.js, ticket-lab.js (shared with SPEC-07); Web/js/core/ProgressStore.js; Web/css/study.css; tests/e2e/study-loop.spec.js, demo-sweep.spec.js, offline.spec.js. Modified: Web/js/app.js (register 4 new routes — 47 to 51), Web/index.html (start route in demo mode), Web/sw.js (precache new assets), .github/workflows/build.yml (E2E job), brand-check script scripts/check-brand.py.

## 03.4 Acceptance summary

REQ-UI-01..08, REQ-BRAND-01..02, REQ-DEMO-01..06 scenarios pass at the release head; E2E runs in CI on the Linux leg (headless Chromium) and the same suite passes manually on ChromeOS; coverage label, disclaimer and preview label snapshots pinned.

## 03.5 Demo-mode operating contract (detail)

Demo mode is a distinct mode, not learner mode with sign-in hidden. Its contract: deterministic seed on entry; a visible "demo mode" label on every screen; synthetic data only; zero outbound calls from simulator content; one-click reset confirmed by a reseed verification pass; no retention of any student's answers after reset. The completion panel tells the truth without pretending to be an exam score: it lists which task conditions were met and which remain, with requested state vs actual state and the action trace — mastery, job qualification and certification-readiness claims are forbidden strings in this panel (snapshot-tested). When a scenario is explicitly an observation task (e.g., "review the dashboard"), completion requires a recorded interpretation response, not merely visiting the route; visiting-without-responding fails the objective.

## 03.6 View contracts (detail)

**track-picker.js** renders from track manifests only — no hardcoded track strings — so the fourth track never requires a view change. **lesson-reader.js** renders reviewed lesson markdown with a reading-progress indicator, objective chips linked from the manifest, and the lesson's practice-set entry point; unreviewed lessons never render (the validator's release set is the only source). **practice.js** presents one item per screen, single/multi-select per item type, study mode with hints and immediate explanation, review mode after submission with per-item rationale; ordering-type items render only after R-03 lands, otherwise they are excluded by the pack compiler. **ticket-lab.js** hosts both CompTIA scenarios from SPEC-07 with its ticket pane, configuration panel, fixed test set and resolution-note field; it owns no scoring logic of its own — validators from SPEC-07 decide, and the view displays the evidence panel (requested state, actual state, action trace, unmet conditions).
