---

# SPEC-02 — Capability: Track/Exam Manifests and Parser Compatibility

## 02.1 Purpose

Give RTP explicit, versioned identity for three tracks and four exams without breaking the five existing Nutanix banks, and close the exam-code truncation gap before any new pack is named.

## 02.2 Requirements

**REQ-MAN-01 (SHALL).** Every track ships a track.json and every exam ships an exam.json conforming to SPEC-01 section 01.03. The four exam IDs are exactly: COMPTIA-A-1201, COMPTIA-A-1202, COMPTIA-NET-009, NCA-75. The three track IDs are exactly: track-aplus, track-netplus, track-nca.
Scenario: Given the content/ tree at the release head, when the manifest validator runs in CI, then all four exam manifests parse, all required fields are present, and the three track manifests reference only those four exam IDs.

**REQ-MAN-02 (SHALL).** Exam identity for new packs resolves from exam.json, never from QuestionParser.DeriveExamCode. A new ManifestExamCatalog (Core/Services/ManifestExamCatalog.cs) reads manifests first and falls back to DeriveExamCode only for manifest-less legacy root files.
Scenario: Given a pack file content/exams/COMPTIA-A-1201/questions/core1-part1.md, when the catalog builds, then the exam ID is COMPTIA-A-1201 and its display name comes from the manifest. Given the same file with no manifest, when the catalog builds, then the legacy derivation path is taken and the truncation is logged as a warning.

**REQ-MAN-03 (SHALL).** DeriveExamCode behavior for existing files is unchanged and pinned. The current DeriveExamCodeTests cases (16 cases incl. NCA-75-Part3-GapFill, NCP-US-Part2-D4, GCP-PCA-Part1) pass unmodified, plus new regression cases proving "COMPTIA-A-1201-Part1.md" would truncate to "COMPTIA-A" — documenting exactly why new packs use manifests.
Scenario: Given the test suite, when `dotnet test RadicalTrainingPlatform.Core.Tests` runs, then all legacy derivation cases and the new truncation-documentation cases pass.

**REQ-MAN-04 (SHALL).** Blueprints are manifest-overridable. A new ManifestBlueprintService (Core/Services/ManifestBlueprintService.cs) implements IBlueprintService, loads exam.json sections/objectives, and takes precedence over HardcodedBlueprintService for manifest-covered exams. HardcodedBlueprintService remains for legacy exams until their manifests exist.
Scenario: Given an NCA-75 exam.json with the current official sections, when the blueprint view renders NCA-75, then sections, objective IDs and weights come from the manifest, and HardcodedBlueprintService.InitNca75 output is not consulted.

**REQ-MAN-05 (SHALL).** Cross-exam ID collision is impossible. The catalog validator fails CI if two packs claim the same exam ID, if a question ID repeats within an exam, or if a progress key would collide across exams (progress keys are namespaced `progress/<examId>/<itemId>`).
Scenario: Given a fixture tree with a duplicated exam ID, when the validator runs, then CI fails naming both files.

**REQ-MAN-06 (SHALL).** Every manifest carries sourceUrl, sourceReviewDate, officialVersion and objectivesDocVersion. Retired-version or stale-review-date manifests produce a loud CI warning; a blueprint change creates review work, never silent relabeling (Plan v2 C-07).
Scenario: Given an exam.json whose sourceReviewDate is more than 180 days old, when CI runs, then the build warns with the exam ID and the stale date; given a manifest missing sourceUrl, CI fails.

**REQ-MAN-07 (SHALL).** Incomplete objective coverage is visible. The track picker and exam screens compute coverage as (objectives with at least one released lesson and one released scored item) / (manifest objectives) and display it with the "beginner preview" label.
Scenario: Given the October 23 A+ pack, when the track screen renders, then it shows the covered objective subset and the preview label; no screen computes or implies pass readiness.

## 02.3 Exact files

New: content/tracks/*/track.json; content/exams/{COMPTIA-A-1201,COMPTIA-A-1202,COMPTIA-NET-009,NCA-75}/exam.json; Core/Models/TrackManifest.cs; Core/Models/ExamManifest.cs; Core/Models/LessonRef.cs; Core/Services/ManifestExamCatalog.cs; Core/Services/ManifestBlueprintService.cs; Core/Abstractions/IManifestLoader.cs; scripts/validate-manifests.py; Core.Tests/ManifestCatalogTests.cs; Core.Tests/ManifestBlueprintTests.cs; additions to Core.Tests/DeriveExamCodeTests.cs.
Modified: Core/Services/QuestionParser.cs (only the AnswerRegex repair in SPEC-09 R-07; no derivation changes); Core.Tests/CompositionRootTests.cs (register new services); scripts/lint-content.py (SPEC-10); .github/workflows/build.yml (run validate-manifests.py).

## 02.4 Commands

```
python3 scripts/validate-manifests.py            # manifest shape + ID collision gate
dotnet test RadicalTrainingPlatform.Core.Tests --filter "FullyQualifiedName~Manifest"
dotnet test RadicalTrainingPlatform.Core.Tests --filter "FullyQualifiedName~DeriveExamCode"
```

## 02.5 Acceptance summary

All REQ-MAN-01..07 scenarios pass at the release head on the self-hosted Linux leg; catalog shows seven exams (five Nutanix legacy + four new IDs with NCA-75 shared) with correct display names; coverage labels render; no legacy test is modified to pass.

## 02.6 Manifest authoring rules for executors

- examId is forever. Once any pack, progress record or remap row references an ID, it never changes; corrections arrive as new pack versions with revision fields.
- Every objective ID in a question's front matter must exist in the exam's manifest; the validator fails on orphans in both directions (question pointing nowhere; released objective with zero released items is allowed but reported).
- sourceReviewDate is set when a human actually opens the official source; the executor never copies a date from this spec without performing the review.
- weightPercent appears only when the official source publishes weights (CompTIA); the NCA manifest omits it and the UI shows the study-allocation label instead (ASM-13).
- Legacy root banks keep filename-derived identity until their own manifests exist; the catalog merges both worlds and the merge is covered by TM-12.
