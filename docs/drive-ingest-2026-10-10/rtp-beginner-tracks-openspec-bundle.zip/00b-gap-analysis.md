---

# SPEC-00B — Gap Analysis: Current State vs Target State

## 00B.1 Method

Gap = the distance between the verified October 5 baseline (SPEC-00 00.2) and the demo/California targets, stated per capability with its closing mechanism. This chapter exists because the owner asked for an explicit gap analysis alongside the audit; every row is owned in SPEC-14.

## 00B.2 Capability gaps

**Content: CompTIA.** Current: zero A+/Network+ items, lessons, manifests or routes. Target: 220 reviewed original items (120 A+, 100 Network+), 9+10 module lessons, two scenarios, two exam manifests each carrying v3.0/v4.0 objective maps. Gap is total: this is greenfield authoring on an existing engine. Closing mechanism: SPEC-02 contracts, SPEC-04/05 content plans, the RedEye review lane (SPEC-08A) and automated originality attestation. Biggest sub-risk was review throughput; the owner resolved it by assigning review to the RedEye lane, so authoring throughput becomes the constraint and is addressed by the visible cut lines in SPEC-11.

**Content: Nutanix NCA.** Current: 140 items on a beta map, beta cheatsheet with a known-stale SSH claim, beta-era logistics (waiver code), hardcoded blueprint, keyword-inferred coverage. Target: current 4-section/14-objective manifest, 40-item reviewed pilot, 14 lessons, corrected companion surfaces. Gap is transformation, not creation: remap, re-verify, author only the true gaps (solutions/tools, licensing, support workflow, performance interpretation). Closing mechanism: SPEC-06 with remap.csv as the control document.

**Learning loop.** Current: desktop exam sessions exist; the PWA has no study UI; persistence stores exist but nothing calls them end-to-end; ordering, retry and answer-format defects corrupt scoring truth. Target: track picker -> lesson -> practice -> scenario -> progress, all offline-capable, all scoring deterministic. Gap: four views, one store wrapper, five scoring repairs. Closing mechanism: SPEC-03, SPEC-09 R-03/R-04/R-05/R-06/R-07.

**Simulator.** Current: 44 scenarios, 78 objectives; boot broken since June; 27 literal-true predicates; 16 seed-auto-pass scenarios; one unpassable scenario; two diverging copies. Target: single source, every scenario genuinely demoable, six new scenarios, full sweep evidence. Gap: validator rewrites plus one import plus a source-collapse decision. Closing mechanism: SPEC-07 contract, SPEC-09 R-01/R-02/R-11, owner directive on single source.

**Tutor.** Current: nothing exists. Target: restricted slice behind a gateway with rehearsed evaluation, or a labeled recorded fallback. Gap: the entire component, bounded deliberately. Closing mechanism: SPEC-08 with its go/no-go gate so a tutor slip never endangers the demo.

**Release machinery.** Current: fail-open security gate, unenforced coverage, deploy without smoke, packaging scripts with proven defects, no LICENSE, stale README, no release bundles (zero releases/tags). Target: gates that provably fail, enforced coverage, predeploy smoke, honest packaging, truthful docs. Closing mechanism: SPEC-10, SPEC-09 R-10/R-12.

**Cross-platform truth.** Current: owner reports Windows-only historical operation; CI covers Linux (Core/Desktop) and Windows (WinForms); macOS untested; Chromebooks unknown. Target: PWA primary across Chrome/Edge/Safari incl. ChromeOS, Avalonia parity Win/Linux/macOS, honest host matrix. Closing mechanism: REQ-XPAT series, TM-50 series.

## 00B.3 Non-gaps (already true, do not re-fix)

Parser format handles the required question shapes (post R-07). Errata infrastructure works and is loaded. Session/State stores work as components. CI runner topology is sound. The five Nutanix banks lint clean, but lint is count-based: 1,598 question headers parse to 1,588 items because ten NCP-AI-Part4 keys use the unsupported 'B and D' form; R-07 repairs both the grammar and the files, and TM-15's reconciliation gate proves zero drops afterward. The guardrail documents exist. Listing these prevents the classic failure of repairing what is not broken while the broken thing ships.

## 00B.4 Gap closure proof

Every gap row names its closing spec; every closing spec names its tests; SPEC-12 maps every test to evidence; SPEC-14 maps every finding to a task. The package is complete when the register shows zero unowned rows and the freeze evidence shows the gap rows closed at the tested head.
