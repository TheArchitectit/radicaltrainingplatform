# RTP Beginner Certification Tracks — OpenSpec Change Package

**Change ID:** rtp-beginner-tracks-2026-10
**Repository:** TheArchitectit/radicaltrainingplatform — default branch main at commit 904106ad388c0d48add662ddcd02153ff5f85537 (October 5, 2026)
**Package date:** October 10, 2026
**Status:** Proposal. Writing only. No repository writes, no branches, no merges, no PRs, no deployments, no purchases are authorized by this package.
**Relationship to prior documents:** This package is a dated addendum to RTP Platform Plan v2 (revision 2, October 1, 2026). Plan v2's rights gates (C-01 through C-08), AI gates (G-01 through G-09), learning requirements (L-01 through L-10), foundation requirements (F-01 through F-06) and delivery rules (D-01 through D-04) are retained and referenced, not replaced. The October 1 architecture audit baseline is historical; this package re-baselines to the October 5 head.

---

# SPEC-00 — Proposal

## 00.1 Why this change exists

Roger needs three beginner certification tracks on the radicaltrainingplatform (RTP):

1. **CompTIA A+ (Core 1 220-1201 and Core 2 220-1202)** — needed for a student demonstration on Friday, October 23, 2026.
2. **CompTIA Network+ (N10-009)** — needed for the same October 23 demonstration.
3. **Nutanix NCA 7.5 (internal exam ID NCA-75)** — needed for Roger's Nutanix HQ visit in California, October 25-28, 2026.

The October 23 event is a demonstration of a complete learning loop to students, not a claim of exam readiness. The October 25-28 trip needs a corrected, current-objective NCA track that Roger can study from and show without presenting a beta blueprint as current fact. Both deadlines are real calendar constraints; everything in this package is sequenced around them.

A track-structure specification dated October 10, 2026 (the "preliminary spec") selected the three-track direction, the module sizes, question targets, technical choices and build sequence. This OpenSpec package converts that working material into a normative, LLM-actionable change package: exact files, exact commands, SHALL requirements, test scenarios, gates, risk register, traceability matrix, assumptions ledger and an executor brief.

## 00.2 Verified baseline (what is actually in the repo today)

The following facts were verified against the repository at the named head on October 10, 2026, by reading the files directly. They supersede older audit statements where they disagree.

**Solution and projects.** RadicalTrainingPlatform.sln contains five projects: RadicalTrainingPlatform.Core (net10.0, no UI dependencies), RadicalTrainingPlatform.Core.Tests (xUnit with Shouldly), RadicalTrainingPlatform.Desktop (net10.0, Avalonia 12.1.3 (all four Avalonia packages on one version line)), RadicalTrainingPlatform.Desktop.Tests (xunit.v3 headless smoke suite, runs as a built executable, not via VSTest), and RadicalTrainingPlatform.Legacy.WinForms (net10.0-windows). RadicalTrainingPlatform.Web is a static PWA (index.html, manifest.json, sw.js, js/, css/) with no .NET dependency.

**Content.** 1,598 question headers across five Nutanix banks: NCA-75 140 (NCA-75-Part1.md, NCA-75-Part2.md, NCA-75-Part3-GapFill.md), NCP-US 400, NCP-CI 363, NCP-AI 335, NCM-MCI 360. All exam markdown lives at the repository root. No A+ or Network+ bank exists. Counts are content counts from the lint tooling and catalog regex, not verified assessment items.

**Question format (parser contract).** Core/Services/QuestionParser.cs parses vendor-neutral markdown with these exact anchors: domain headings `## DOMAIN <n>` (case-insensitive), question headings `### Q<n>`, options as `- A) text` through `- F) text`, answer keys as `**Answer: X**` or `**Correct Answer: X, Y**` supporting multi-select, plus explanations. The parser applies errata after parsing through IErrataProvider.

**Exam-code derivation (the compatibility gap that matters most).** QuestionParser.DeriveExamCode iteratively strips `-PartN`, `-DN` and `-GapFill` suffixes, then keeps at most the first two hyphen-separated segments. DeriveExamCodeTests.cs proves current behavior: "NCA-75-Part1.md" maps to "NCA-75" only because the second segment is numeric. A file named "COMPTIA-A-1201-Part1.md" would derive "COMPTIA-A" — truncating the exam number and colliding Core 1 with Core 2. This is why the new tracks cannot rely on filename-derived codes and must use explicit manifests (SPEC-02).

**Blueprint service.** Core/Services/HardcodedBlueprintService.cs hardcodes blueprints per exam. InitNca75 (lines 540-641) defines the NCA-75 blueprint as four sections — "Describe Lifecycle Management" (20%), "Describe Nutanix Basic Administration" (30%), "Maintain Environmental Health" (25%), "Describe Cluster Configuration Options" (25%) with objectives 1.1 through 4.4. This is the 7.5 beta structure. The current official NCA 7.5 guide (June 15, 2026) uses four different sections — Solutions and tools (1.1-1.3), Platform administration (2.1-2.4), Cluster configuration and maintenance (3.1-3.3), Health and monitoring (4.1-4.4) — targeting AOS 7.5, AHV 11.0 and Prism Central pc.7.5. The hardcoded section order and objective IDs do not match the official guide and must be replaced or overridden by a versioned manifest (SPEC-05).

**Errata.** errata.json at the repository root (version 1) contains two corrections: NCA-75-Part1.md Q35 corrected to D (Prism Central scale-out 3-VM deployment supports 25,000 VMs) and NCA-75-Part3-GapFill.md Q3 corrected to A (SSH enabled by default on fresh AOS 7.5 installs; the plan to disable was deferred). Core/Services/Errata.cs (JsonErrataStore) loads errata.json, applies answerKey corrections keyed by uppercase (file, questionId), and treats missing or malformed errata as non-fatal. The October 1 audit's "errata.json unused" statement is stale. However, studyguides/CHEATSHEET-NCA-75.md line 96 still asserts "CVM SSH disabled by default on fresh installs" — directly contradicting the applied errata. The cheatsheet is a beta document and is input for review, never a current authority.

**Persistence.** Core/Services/SessionStore.cs implements ISessionStore/JsonSessionStore: lab-simulator session JSON persisted under the application data directory in a sessions/ folder, thread-safe, with path-traversal-safe session IDs. Web/js/core/StateStore.js persists state in IndexedDB (database RadicalTrainingPlatformLab, object store "state", keyPath "key") with a localStorage fallback (key prefix lab_). The October 1 audit's blanket "no persistence" statement is superseded. What remains unproven is learner quiz-progress durability (attempts, flags, per-question results) — the existing stores serve the simulator. SPEC-02 and SPEC-06 add and test that separately.

**Web app.** Web/js/app.js registers exactly 47 router.register routes. All are Nutanix simulator views (PE, PC, CI, AI categories). The Web app is a Nutanix simulator, not a multi-vendor study UI; there is no track picker, lesson reader, practice screen or progress screen. The earlier "49 views" figure is not a verified live count and must not be quoted. The simulator exists in two diverging copies: RadicalTrainingPlatform.Web and RadicalTrainingPlatform.Legacy.WinForms/LabSimulator (both contain js/app.js and js/core/StateStore.js). One authoritative asset set must be chosen before adding scenarios (SPEC-06).

**Content lint.** scripts/lint-content.py validates exam markdown: question count equals answer count per file, answers match the recognized format, no empty answer lines. It globs only REPO_ROOT/*.md and skips files whose names start with README/CLAUDE/CHANGELOG/etc. or contain CHEATSHEET/LAB/ROADMAP/DESIGN/SPRINT. New track content placed anywhere but the root, or named with a skipped substring, is silently unlinted (SPEC-08).

**CI.** .github/workflows/build.yml has two legs. build-linux runs on the self-hosted fleet runner (label devgate-rtp, host ucs03, image bakes the .NET 10 SDK): lints content, builds Core and Desktop, runs Core.Tests with coverage, runs the headless Avalonia smoke suite, runs the vulnerability gate, verifies no System.Windows.Forms references in Core (source grep plus strings scan of the compiled DLL), uploads artifacts. build-winforms runs on windows-latest (deliberate: the repo is public, hosted minutes are free): lints content with PYTHONIOENCODING=utf-8 (cp1252 consoles cannot print the lint emoji; this killed the 2026-09-02 Windows legs), sets up .NET 10, builds the WinForms leg. .github/workflows/pwa-deploy.yml deploys the PWA via GitHub Pages on ubuntu-latest (actions/deploy-pages is GitHub-hosted-only).

**Vulnerability gate defect (release-relevant).** .github/scripts/vuln_gate.py is a blocking gate over `dotnet list <proj> package --vulnerable --include-transitive --format json`. Lines 74-75 iterate `data if isinstance(data, list) else []` — but dotnet emits a root object (`{"version":1,"parameters":"...","projects":[...]}` with per-project frameworks, topLevelPackages, transitivePackages and lowercase "advisoryurl" fields). The loop body therefore never executes, every project reports "OK: no vulnerable packages", and the gate prints PASS. Verified live on October 10, 2026 with a scratch project carrying Newtonsoft.Json 12.0.1 (a real High advisory): the gate printed PASS and exited 0. Current repository packages are clean; the defect is the gate, not the dependency set. A blocking security gate that cannot fail is worse than no gate, because every future green run is fabricated evidence. Repair is in scope as gate work (SPEC-08), sequenced before any demo build is tagged.

**Guardrails.** CLAUDE.md encodes the project rules: UI depends on Core, Core never depends on UI; Core uses IFileProvider rather than System.IO.Directory; read before editing; three-strikes halt; no secrets; no force-push to main. .guardrails/ contains scope.json and secret-allowlist.json. The .devgate file wires the DevGate harness. The chore/external-audit branch has since been merged to main (merge commits 0014111 and f539471, per the October 10 audit's merge-history check); the current tree retains .guardrails/secret-allowlist.json and CLAUDE.md, so the October 1 "do not merge" warning is historical. No branch deletion or cleanup follows from this package.

**Licensing.** No LICENSE file exists at the head (confirmed 404), although the README claims BSD-3. Two Nutanix vendor PDFs live in docs/ (AHV-Admin-Guide-v11_0.pdf, Prism-Central-Guide-vpc_7_5.pdf). Both are Plan v2 rights-review items (C-03) and are unchanged by this package.

## 00.3 Vendor policy posture and non-endorsement constraint (owner-directed, October 10, 2026)

CompTIA's unauthorized-training-materials policy (https://www.comptia.org/en-us/resources/test-policies/unauthorized-training-materials/) targets candidates who use brain dumps and actual exam items; The page's explicit language is that CompTIA does not authorize or condone AI, LLMs or similar tools generating study questions, practice exams or exam-related content, in a policy aimed at candidates. Roger's position is that no vendor policy can legally prevent original AI-drafted training content. This package renders no legal verdict in either direction; it records the explicit policy language and encodes the owner's chosen product posture as the binding constraint. Roger's own direction on October 10, 2026, verbatim from his channel: "They can't legally prevent anyone for making ai generated training content" and "We will clearly state this isn't official training or endorsed training material." The binding constraints below encode that direction as SHALLs:

- **Originality with exam-item distance.** Every scored question SHALL be original work with no proximity to actual CompTIA or Nutanix exam items. Any item resembling a remembered or leaked exam question enters the Plan v2 exam-integrity quarantine (C-04) and cannot ship.
- **RedEye review before publish.** Every scored item passes the RedEye AI review lane (key verification, mapping check, bias detection, originality screen, written log) before release; an automated seeded-defect self-test enforces lane accuracy and Roger is not the reviewer of record (SPEC-08A, owner-directed). AI drafting is allowed; no item ships without a passing lane log.
- **No endorsement implication.** The product SHALL NOT use "approved", "official", "certified by", or CompTIA/Nutanix logos and marks in branding. Permitted language is nominative fair use: "helps you prepare for the CompTIA Network+ exam" and equivalent phrasing.
- **Exact non-endorsement disclaimer** on every track surface and in the October 23 demo script: "This is independent study material. It is not official training and is not endorsed or approved by CompTIA, Nutanix, or any other certification body." The exact string is normative (REQ-BRAND-02) and is tested as a UI fixture.
- **Tutor framing.** The live tutor slice is framed as general IT-skills coaching over original lessons, never as exam preparation endorsed by any vendor (SPEC-08).

## 00.4 Scope

**In scope — three tracks, four exam IDs, one shared runtime extension:**

| Track ID | Exam IDs | Vendor | Deadline driver |
|---|---|---|---|
| track-aplus | COMPTIA-A-1201, COMPTIA-A-1202 | CompTIA | Oct 23 demo |
| track-netplus | COMPTIA-NET-009 | CompTIA | Oct 23 demo |
| track-nca | NCA-75 (displayed as NCA 7.5) | Nutanix | Oct 25-28 California |

1. A track/lesson manifest system with explicit exam-ID mapping, versioned objective maps, stable content IDs and per-item provenance, extending the existing parser and repository seams (SPEC-02).
2. Beginner study screens in the Web PWA: track picker, lesson reader, practice set runner with deterministic scoring and review, local progress with reset (SPEC-02, SPEC-06).
3. A+ content: two exam packs, 120 reviewed original items total (60 per core), module/lesson structure per official V15 objectives v3.0, one shared help-desk-ticket simulator scenario (SPEC-03).
4. Network+ content: one exam pack, 100 reviewed original items, five modules per N10-009 objectives v4.0, one default-gateway scenario sharing the A+ renderer (SPEC-04).
5. NCA-75 remap: inventory and remap of the existing 140-item bank onto the current official blueprint, a reviewed 40-item pilot, 14 short lessons, four deterministic scenarios, replacement of the hardcoded beta blueprint with a versioned manifest, correction of the stale cheatsheet claim (SPEC-05).
6. Deterministic scenario validation: state-based completion checks with negative fixtures, replacing any return-true completion stubs; shared synthetic-ticket renderer; clean reset between student groups (SPEC-06).
7. A restricted "ask the tutor" slice behind a backend gateway, sized for the demo under the CompTIA constraint, with a rehearsed evaluation set and a labeled recorded fallback (SPEC-07).
8. Gate repair and extension: vuln_gate.py parser fix with real dotnet JSON fixtures, lint-content.py coverage for the new content layout, catalog/parser regression tests for multi-segment exam codes, DevGate wiring per the owner's standard (SPEC-08).
9. Delivery plan: dependency-ordered tasks, sprint files for October 10-22 and the post-EPIC NCA window, test matrix, risk register, traceability to Plan v2, assumptions ledger, executor brief (SPEC-09 through SPEC-14).

**Out of scope (explicit non-goals):** no full PWA-first rewrite; no account system, cloud sync or spaced repetition for these deadlines; no three new simulators; no public release or public deployment; no unreviewed AI-drafted content in any scored item (AI drafting itself is allowed under the SPEC-00 00.3 constraints: originality, exam-item distance, RedEye review before publish, disclaimer); no live AI in assessment mode; no real-infrastructure calls from any scenario; no modification, removal or history rewrite of the existing Nutanix banks or vendor PDFs; no merge of chore/external-audit; no license selection (remains an owner decision under Plan v2).

## 00.5 Success definition

October 23 demo-ready means: a presenter can open the PWA on the demo host, pick track-aplus or track-netplus, read one complete lesson per exam, run a scored practice set of reviewed original items, complete a deterministic simulated help-desk task, ask the tutor for a hint inside its stated limits (or play the labeled recorded example), reset the station for the next group, and do all of it with the network cable unplugged except the optional tutor call. Incomplete objective coverage is visibly labeled "beginner preview". No pass-prediction claim is made anywhere.

October 25-28 California-ready means: the NCA track presents the current official blueprint (sections, objective IDs, product versions AOS 7.5 / AHV 11.0 / pc.7.5), 14 short lessons, 40 reviewed remapped or newly authored questions, four tested deterministic scenarios, and a corrected objective map; beta labels survive only where a retained claim was checked.

Both deadlines share one release condition: every gate in SPEC-08 green at the tested head, including the repaired vulnerability gate proven against a fixture that must fail it.

## 00.6 Package map and glossary

Package map: SPEC-00 proposal and verified baseline; SPEC-00B gap analysis; SPEC-01 design; SPEC-02 manifests; SPEC-03 study UI and demo mode; SPEC-04 A+ track; SPEC-05 Network+ track; SPEC-06 NCA remap; SPEC-07 deterministic scenarios; SPEC-08 tutor; SPEC-09 runtime repair; SPEC-10 CI/packaging gates; SPEC-11 tasks and sprints; SPEC-12 test matrix; SPEC-13 risks; SPEC-14 traceability and finding register; SPEC-15 assumptions; SPEC-16 executor brief; SPEC-17 sources.

Glossary: **Pack** — released content for one exam manifest. **Cut** — the reviewed subset released for a deadline. **Seed** — a scenario's deterministic initial fixture. **Sweep** — the scripted all-scenario boot/run/complete pass (TM-45). **Remap** — attaching current-objective mappings to existing items without renumbering. **Quarantine** — excluded-from-release status with a recorded reason (integrity or type). **Gate fixture** — input crafted to prove a gate fails correctly. **Beginner preview** — the visible label for partial objective coverage. **Recorded example** — prewritten tutor output labeled as not live. **Finding register** — SPEC-14's zero-unowned-rows table.
